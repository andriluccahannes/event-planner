package com.luccabauer.eventplanner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventPlannerApplicationTests {

	@Test
	void contextLoads() {
	}

}
